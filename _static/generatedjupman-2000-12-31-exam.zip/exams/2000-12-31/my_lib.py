
"""
An example library you can share between many exercises / exams
"""

def myfun(x):
    print(x)