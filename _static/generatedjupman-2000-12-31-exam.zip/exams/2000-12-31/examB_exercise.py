

def inc(x):
    raise Execption("WRITE SOMETHING")